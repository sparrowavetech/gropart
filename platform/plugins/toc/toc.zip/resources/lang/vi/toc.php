<?php

return [
    'post_content'  => 'Mục lục',
    'show'          => 'Hiển thị',
    'hide'          => 'Ẩn',
];
