<?php

return [
    'post_content'  => 'Table of contents',
    'show'          => 'Show',
    'hide'          => 'Hide',
];
