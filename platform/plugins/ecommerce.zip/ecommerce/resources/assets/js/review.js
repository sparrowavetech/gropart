$(document).ready(() => {
    $('#rating').rating({'size': 'xs'});
});
