$(document).ready(function () {
    BDashboard.loadWidget($('#widget_ecommerce_report_general').find('.widget-content'), route('ecommerce.report.dashboard-widget.general'));
});
