<?php

return [
    'name'   => 'Product attributes',
    'create' => 'New product attribute',
    'edit'   => 'Edit product attribute',
    'intro'  => [
        'title'       => 'Manage product attributes',
        'description' => 'Product attribute such as color, width, height ...',
        'button_text' => 'Create product attribute',
    ],
];
