<?php

return [
    'name'       => 'Taxes',
    'create'     => 'Create a tax',
    'edit'       => 'Edit tax :title',
    'title'      => 'Title',
    'percentage' => 'Percentage %',
    'priority'   => 'Priority',
    'select_tax' => '-- select --',
];
