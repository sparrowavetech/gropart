<?php

return [
    'products'     => [
        'name'             => 'Export products',
        'title'            => 'Export Products (CSV)',
        'total_products'   => 'Total products',
        'total_variations' => 'Total variations',
    ],
    'start_export' => 'Start export',
    'exporting'    => 'Exporting...',
    'export'       => 'Export',
];
