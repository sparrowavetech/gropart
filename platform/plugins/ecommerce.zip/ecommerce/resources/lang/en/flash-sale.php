<?php

return [
    'name'     => 'Flash sales',
    'create'   => 'New flash sale',
    'edit'     => 'Edit flash sale',
    'products' => 'Products',
];
