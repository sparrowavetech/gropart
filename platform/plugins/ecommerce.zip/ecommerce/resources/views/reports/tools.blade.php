<div class="tools">
    <a href="#" class="expand" data-bs-toggle="tooltip" title="{{ trans('core/dashboard::dashboard.collapse_expand') }}"></a>
    <a href="#" class="reload" data-bs-toggle="tooltip" title="{{ trans('core/dashboard::dashboard.reload') }}"></a>
    <a href="#" class="fullscreen" data-bs-toggle="tooltip" data-bs-original-title="{{ trans('core/dashboard::dashboard.fullscreen') }}" title="{{ trans('core/dashboard::dashboard.fullscreen') }}"> </a>
</div>
