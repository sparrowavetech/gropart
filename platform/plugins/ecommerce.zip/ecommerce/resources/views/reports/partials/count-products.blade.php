<div class="dashboard-stat2 bordered">
    <div class="display">
        <div class="number">
            <h3 class="font-red-haze">
                <span data-counter="counterup" data-value="{{ $count['products'] }}">0</span>
            </h3>
            <small>{{ trans('plugins/ecommerce::reports.count.products') }}</small>
        </div>
        <div class="icon">
            <i class="fab fa-product-hunt"></i>
        </div>
    </div>

</div>