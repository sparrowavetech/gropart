<div class="dashboard-stat2 bordered">
    <div class="display">
        <div class="number">
            <h3 class="font-purple-soft">
                <span data-counter="counterup" data-value="{{ $count['customers'] }}">0</span>
            </h3>
            <small>{{ trans('plugins/ecommerce::reports.count.customers') }}</small>
        </div>
        <div class="icon">
            <i class="icon-user"></i>
        </div>
    </div>
</div>
