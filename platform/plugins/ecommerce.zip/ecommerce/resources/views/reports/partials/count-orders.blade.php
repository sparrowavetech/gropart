<div class="dashboard-stat2 bordered">
    <div class="display">
        <div class="number">
            <h3 class="font-blue-sharp">
                <span data-counter="counterup" data-value="{{ $count['orders'] }}">0</span>
            </h3>
            <small>{{ trans('plugins/ecommerce::reports.count.orders') }}</small>
        </div>
        <div class="icon">
            <i class="icon-basket"></i>
        </div>
    </div>
</div>