<div class="rating_wrap d-inline-block">
    <div class="rating">
        <div class="product_rate" style="width: {{ $star * 20 }}%"></div>
    </div>
</div>
