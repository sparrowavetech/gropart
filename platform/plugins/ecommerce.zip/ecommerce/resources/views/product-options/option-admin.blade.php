@include('plugins/ecommerce::product-options.option-settings.field')
@include('plugins/ecommerce::product-options.option-settings.multiple')
<div class="empty">{{ trans('plugins/ecommerce::product-option.please_choose_option_type') }}</div>
