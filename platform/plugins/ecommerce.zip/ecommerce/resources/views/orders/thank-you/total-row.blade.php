<div class="row">
    <div class="col-6">
        <p>{!! BaseHelper::html($label) !!}:</p>
    </div>
    <div class="col-6 float-end">
        <p class="price-text text-end"> {{ BaseHelper::html($value) }} </p>
    </div>
</div>
