<?php

return [
    'settings' => [
        'prefix' => 'ecommerce_shipping_',
    ],
];
