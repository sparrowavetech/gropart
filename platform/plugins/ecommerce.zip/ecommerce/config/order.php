<?php

return [
    'default_order_start_number' => env('ECOMMERCE_DEFAULT_ORDER_START_NUMBER', 10000000),
    'default_order_weight'       => env('ECOMMERCE_DEFAULT_ORDER_WEIGHT', 0.01),
];
