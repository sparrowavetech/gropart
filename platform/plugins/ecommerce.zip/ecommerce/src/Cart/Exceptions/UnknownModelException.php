<?php

namespace Botble\Ecommerce\Cart\Exceptions;

use RuntimeException;

class UnknownModelException extends RuntimeException
{
}
