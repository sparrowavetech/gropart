<?php

return [
    'all'  => 'All',
    'date' => 'Date',
    'name' => 'System logs',
];
