$(document).ready(() => {
    Botble.initCodeEditor('header_html', 'html');
    Botble.initCodeEditor('body_html', 'html');
    Botble.initCodeEditor('footer_html', 'html');
});
