$(document).ready(() => {
    Botble.initCodeEditor('header_js', 'javascript');
    Botble.initCodeEditor('body_js', 'javascript');
    Botble.initCodeEditor('footer_js', 'javascript');
});
