@if (!empty($url))
    <div style="position: relative; display: block; height: 0; padding-bottom: 56.25%; overflow: hidden; margin-bottom: 20px;">
        <iframe style="position: absolute; top: 0; bottom: 0; left: 0; width: 100%; height: 100%; border: 0;" allowfullscreen frameborder="0" src="{{ $url }}"></iframe>
    </div>
@endif
