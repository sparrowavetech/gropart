<div class="form-group mb-3">
    <label class="control-label">{{ __('Address') }}</label>
    {!! Form::input('text', 'address', $content, ['class' => 'form-control', 'data-shortcode-attribute' => 'content', 'placeholder' => '24 Roberts Street, SA73, Chester']) !!}
</div>
